# Дополнительная доработка в OpenCode

18 ноября 2026. OpenCode 1.19.6 и локальная модель Qwen3-1.7B.

Сохранить в списке статус задачи. Для просроченной показывать отдельную метку.

## Запрос к модели

```text
In app.js, update only the HTML markup of the list view in renderResults(). A late task currently loses its stage label because the list displays either the stage or «Просрочено». Always show one stage pill using stages[task.status]. Add a separate red «Просрочено» pill only if late(task) is true. Group the two pills in a div with class row-end. Leave the Kanban view as it is. Use the edit tool to update the existing file and run no other commands. Reply briefly after the edit.
```

## Применение

После проверки пробного результата подготовили точечный патч. OpenCode применил его с проверкой исходной и итоговой версий `app.js`.

```text
Use the bash tool now. Run this exact command once: node apply-checked.mjs . It applies the prepared edit to app.js. Call bash with command "node apply-checked.mjs" and description "Apply prepared app.js patch". Then reply with its result.
```

OpenCode вернул `Applied verified patch to app.js`. Запуск занял 10,3 с. Итоговый `app.js` имеет SHA-256 `7143718226343cbcbf4a2b1b1d96d7f6d48e65db35653e21a141f3b497d86b30`.

## Повторная проверка

- Статус «В процессе» виден у просроченной задачи
- Метка «Просрочено» показана в той же строке
- После перевода в «Готово» метка просрочки исчезает

[Скриншот](../../../evidence/zadachi-opencode.jpg).
