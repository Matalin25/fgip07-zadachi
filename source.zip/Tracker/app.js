const people = { marina: 'Марина', nikita: 'Никита', lena: 'Елена' };
const stages = { todo: 'К работе', work: 'В процессе', done: 'Готово' };
const priorities = { high: 'Высокий', normal: 'Обычный', low: 'Низкий' };
const projects = ['SEO автошколы', 'Сайт автосервиса', 'Общее'];
const model = storage('tasks', () => ({
  tasks: [
    ['t1', 'Собрать запросы по районам', 'Выделить коммерческую семантику.', projects[0], 'marina', 'todo', 'high', 1],
    ['t2', 'Сверить прайс с владельцем', 'Проверить цены для карточек услуг.', projects[1], 'nikita', 'todo', 'normal', 4],
    ['t3', 'Подготовить структуру услуг', 'Согласовать страницы ТО и подвески.', projects[1], 'lena', 'work', 'high', -1],
    ['t4', 'Проверить индексацию страниц', 'Сверить отчёт Яндекс Вебмастера.', projects[0], 'marina', 'work', 'normal', 2],
    ['t5', 'Обновить карточку филиала', 'Уточнить график и точку на карте.', projects[0], 'nikita', 'done', 'low', -2],
    ['t6', 'Зафиксировать задачи на спринт', 'Распределить задачи команды.', projects[2], 'lena', 'done', 'normal', 0]
  ].map(([id, title, note, project, assignee, status, priority, offset]) =>
    ({ id, title, note, project, assignee, status, priority, due: dateKey(new Date(), offset) }))
}));
const tasks = model.state.tasks;
const navigation = [['board','▤','Доска'], ['list','≡','Все задачи']];
const filters = { project: '', assignee: '', search: '' };
let view = 'board';

function late(task) {
  return Boolean(task.due && task.due < dateKey() && task.status !== 'done');
}

function matchingTasks() {
  const query = filters.search.trim().toLocaleLowerCase('ru');
  return tasks.filter(task =>
    (!filters.project || task.project === filters.project) &&
    (!filters.assignee || task.assignee === filters.assignee) &&
    (!query || (task.title + ' ' + task.note).toLocaleLowerCase('ru').includes(query)));
}

function card(task) {
  const priorityClass = { high: 'hot', normal: 'plain', low: 'good' }[task.priority];
  const title = escapeHtml(task.title);
  return `<article class="card">
    <div class="card-top"><span class="tag ${priorityClass}">${priorities[task.priority]}</span><span class="muted" style="font-size:11px">${escapeHtml(task.project)}</span></div>
    <h3><button type="button" class="card-title" data-edit="${escapeHtml(task.id)}">${title}</button></h3>
    <p>${escapeHtml(task.note)}</p>
    <div class="card-foot"><span class="${late(task) ? 'tag hot' : ''}">${task.due ? formatDate(task.due) + (late(task) ? ' · Просрочено' : '') : 'Без срока'}</span>
      <span><span class="letter" aria-hidden="true">${people[task.assignee].slice(0,1)}</span> ${people[task.assignee]}</span></div>
  </article>`;
}

function renderResults() {
  const filtered = matchingTasks();
  const results = document.querySelector('[data-results]');
  if (view === 'board') {
    results.innerHTML = `<div class="board">${Object.entries(stages).map(([status, label]) => {
      const tasksInLane = filtered.filter(task => task.status === status);
      const cards = tasksInLane.map(card).join('');
      const count = tasksInLane.length;
      return `<section class="lane" data-status="${status}" aria-label="${label}">
        <h3 class="lane-head"><span class="dot" aria-hidden="true"></span>${label}<span class="tag plain">${count}</span></h3>
        ${cards || '<p class="empty">Задач в этом статусе нет.</p>'}</section>`;
    }).join('')}</div>`;
  } else {
    results.innerHTML = `<div class="panel"><ul class="rows">${filtered.map(task => `<li class="row"><div class="row-item">
      <span class="unit" aria-hidden="true">${people[task.assignee].slice(0,1)}</span>
      <div><button type="button" class="card-title" data-edit="${escapeHtml(task.id)}">${escapeHtml(task.title)}</button>
      <small>${escapeHtml(task.project)} · ${people[task.assignee]}${task.due ? ' · ' + formatDate(task.due) : ''}</small></div>
      </div><div class="row-end"><span class="tag">${stages[task.status]}</span>${late(task) ? '<span class="tag hot">Просрочено</span>' : ''}</div></li>`).join('') || '<li class="empty">Задачи по этим фильтрам не найдены.</li>'}</ul></div>`;
  }
}

function render() {
  nav(navigation, view);
  putTop('Команда / <strong>Рабочие проекты</strong>', '<span class="tag plain">Демо команды</span>');
  const work = tasks.filter(task => task.status === 'work').length;
  const done = tasks.filter(task => task.status === 'done').length;
  const overdue = tasks.filter(late).length;
  root.innerHTML = `
    <section class="hero"><div><h1>Рабочие проекты</h1><p>Задачи, ответственные и сроки команды в одной доске.</p></div>
      <button type="button" class="button" data-add>+ Новая задача</button></section>
    ${metrics([['Всего задач', tasks.length, overdue ? 'Просрочено: ' + overdue : 'Во всех проектах'], ['В процессе', work, 'Задачи команды'], ['Готово', done, 'Закрытые задачи']])}
    <section><div class="section-head"><h2>${view === 'board' ? 'Канбан-доска' : 'Все задачи'}</h2><div class="controls">
      <input class="control" aria-label="Поиск задач" placeholder="Поиск по задачам" data-filter="search" value="${escapeHtml(filters.search)}">
      <select class="control" aria-label="Проект" data-filter="project">${options([['','Все проекты'], ...projects.map(item => [item,item])], filters.project)}</select>
      <select class="control" aria-label="Исполнитель" data-filter="assignee">${options([['','Все исполнители'], ...Object.entries(people)], filters.assignee)}</select>
      <button type="button" class="button" data-clear>Сбросить</button>
    </div></div><div data-results></div></section>`;
  renderResults();
}

function showEditor(task) {
  const draft = task ?? { title: '', note: '', assignee: 'marina', status: 'todo', priority: 'normal', due: '', project: projects[0] };
  openDialog(task ? 'Карточка задачи' : 'Новая задача', `
      <label>Название<input name="title" class="control" required maxlength="90" value="${escapeHtml(draft.title)}"></label>
      <label>Описание<textarea name="note" class="control" maxlength="260">${escapeHtml(draft.note)}</textarea></label>
      <div class="form-cols"><label>Проект<select class="control" name="project">${options(projects.map(item => [item,item]), draft.project)}</select></label>
      <label>Исполнитель<select class="control" name="assignee">${options(Object.entries(people), draft.assignee)}</select></label>
      <label>Статус<select name="status" class="control">${options(Object.entries(stages), draft.status)}</select></label>
      <label>Приоритет<select name="priority" class="control">${options(Object.entries(priorities), draft.priority)}</select></label>
      <label>Срок<input class="control" type="date" name="due" min="2020-01-01" max="2099-12-31" value="${escapeHtml(draft.due)}"></label></div>`,
    '<button type="button" class="button" data-close-form>Отмена</button><button class="button primary" type="submit">Сохранить</button>',
    fields => {
      const draft = Object.fromEntries(fields);
      draft.title = draft.title.trim();
      draft.note = draft.note.trim();
      if (!draft.title) return 'Введите название задачи.';
      if (task) Object.assign(task, draft);
      else tasks.push({ id: newId(), ...draft });
      model.save();
      dialog.close();
      render();
      notify(task ? 'Задача обновлена' : 'Задача добавлена');
    });
  dialog.querySelector('[data-close-form]').onclick = () => dialog.close();
}

document.addEventListener('click', event => {
  const trigger = event.target.closest('button');
  if (!trigger) return;
  if (trigger.dataset.view) {
    view = trigger.dataset.view;
    render();
    document.querySelector('[data-view="' + view + '"]').focus();
  }
  if (trigger.hasAttribute('data-clear')) {
    Object.assign(filters, { project: '', assignee: '', search: '' });
    render();
    document.querySelector('[data-filter="search"]').focus();
  }
  if (trigger.hasAttribute('data-add')) showEditor();
  if (trigger.dataset.edit) showEditor(tasks.find(task => task.id === trigger.dataset.edit));
});
document.addEventListener('input', event => {
  const target = event.target;
  if (!target.dataset.filter) return;
  filters[target.dataset.filter] = target.value;
  renderResults();
});
render();
